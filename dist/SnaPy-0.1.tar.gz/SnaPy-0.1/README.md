# SnaPy
Python library for detecting near duplicate texts in a corpus using Locality Sensitive Hashing.<br>
As described in Mining Massive Datasets http://infolab.stanford.edu/~ullman/mmds/ch3.pdf.

### Installation
Install SnaPy using: `pip install snapy`<br>
Install mmh3 library needed for Minhash using: `pip install mmh3`

### Authors
Justin Boylan-Toomey

### License
MIT License
