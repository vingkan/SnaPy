# Jaccardupy
Python library for detecting near duplicate texts in a corpus using Locality Sensitive Hashing.

### License
MIT License
